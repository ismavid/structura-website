# Structura - Consultoría en Automatización con IA

Este es el sitio web oficial de **Structura**, una consultora especializada en liberar el tiempo de las organizaciones mediante la automatización de procesos con Inteligencia Artificial.

## Stack Tecnológico
- **Framework**: React 19 + Vite
- **Estilos**: Tailwind CSS 4
- **Animaciones**: Framer Motion (motion/react)
- **Iconos**: Lucide React
- **Tipografía**: Inter (Google Fonts)

## Características
- ✅ **Diseño Premium**: Estética moderna y profesional orientada a la conversión.
- ✅ **Interactividad**: Efectos de cursor glow, animaciones on-scroll y micro-interacciones.
- ✅ **Responsive**: Optimizado para móviles, tablets y escritorio.
- ✅ **Performance**: Carga rápida y animaciones fluidas.
- ✅ **SEO Ready**: Estructura semántica y meta tags configurados.

## Instalación Local

1. Clona el repositorio.
2. Instala las dependencias:
   ```bash
   npm install
   ```
3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```

## Personalización

### Colores
Los colores de marca están definidos en `src/index.css` dentro de la directiva `@theme` de Tailwind 4. Puedes modificarlos allí para actualizar toda la identidad visual.

### Logo
El logo es un componente SVG ubicado en `public/logo.svg`. Puedes reemplazarlo por tu propio archivo manteniendo el mismo nombre.

### Contenido
El contenido principal (textos, servicios, métricas) se encuentra en `src/App.tsx`.

## Despliegue en Vercel

Este proyecto está listo para ser desplegado en Vercel:
1. Conecta tu repositorio de GitHub a Vercel.
2. Vercel detectará automáticamente la configuración de Vite.
3. Haz clic en "Deploy".

---
**Structura** — *Tu tiempo, donde realmente importa.*
