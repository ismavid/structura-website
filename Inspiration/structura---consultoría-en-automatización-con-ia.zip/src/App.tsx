import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  Phone, 
  MessageCircle,
  ArrowRight
} from 'lucide-react';

export default function App() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="relative min-h-screen bg-black text-white flex flex-col items-center justify-center px-6 py-20 overflow-hidden">
      <div className="noise" />
      <div 
        className="cursor-glow hidden md:block" 
        style={{ left: mousePos.x, top: mousePos.y }}
      />

      {/* Background Image - Rotating Earth */}
      <div className="absolute inset-0 z-0 opacity-20 flex items-center justify-center">
        <motion.img 
          src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2000" 
          alt="Rotating Earth" 
          className="w-[150%] h-[150%] object-cover max-w-none"
          animate={{ rotate: 360 }}
          transition={{ duration: 200, repeat: Infinity, ease: "linear" }}
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black via-transparent to-black" />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <main className="relative z-10 max-w-4xl w-full flex flex-col items-center text-center">
        {/* Large Logo with Animation */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8, rotate: -10 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="mb-12 relative"
        >
          <motion.div
            animate={{ 
              scale: [1, 1.05, 1],
              rotate: [0, 2, -2, 0]
            }}
            transition={{ 
              duration: 10, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
          >
            <img 
              src="/logo.svg" 
              alt="Structura Logo" 
              className="w-48 h-48 md:w-64 md:h-64 drop-shadow-[0_0_50px_rgba(93,164,176,0.4)]" 
            />
          </motion.div>
          {/* Subtle glow behind logo */}
          <div className="absolute inset-0 bg-teal-accent/20 blur-[100px] rounded-full -z-10" />
        </motion.div>

        {/* Brand Identity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          <h1 className="text-2xl md:text-3xl font-bold tracking-[0.3em] text-teal-accent mb-4">STRUCTURA</h1>
          <p className="text-4xl md:text-7xl font-bold mb-8 tracking-tighter leading-tight">
            Tu tiempo, <br className="md:hidden" />
            <span className="text-white/40">donde realmente importa</span>
          </p>
          
          <p className="text-lg md:text-xl text-slate max-w-2xl mx-auto leading-relaxed mb-12 font-light">
            Liberamos el potencial de tu organización mediante la automatización inteligente. 
            Diseñamos soluciones con IA que eliminan procesos repetitivos, permitiendo que tu equipo se enfoque en la innovación y el crecimiento.
          </p>
        </motion.div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-3xl mb-16"
        >
          <a href="mailto:hola@structura.ai" className="group flex flex-col items-center p-8 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-teal-accent transition-all duration-500">
            <Mail className="text-teal-accent mb-4 group-hover:scale-110 transition-transform duration-500" size={32} />
            <span className="text-[10px] font-bold text-slate mb-1 uppercase tracking-[0.2em]">Correo</span>
            <span className="text-white font-medium text-sm">hola@structura.ai</span>
          </a>

          <a href="tel:+1234567890" className="group flex flex-col items-center p-8 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-teal-accent transition-all duration-500">
            <Phone className="text-teal-accent mb-4 group-hover:scale-110 transition-transform duration-500" size={32} />
            <span className="text-[10px] font-bold text-slate mb-1 uppercase tracking-[0.2em]">Teléfono</span>
            <span className="text-white font-medium text-sm">+1 (234) 567-890</span>
          </a>

          <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer" className="group flex flex-col items-center p-8 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-teal-accent transition-all duration-500">
            <MessageCircle className="text-teal-accent mb-4 group-hover:scale-110 transition-transform duration-500" size={32} />
            <span className="text-[10px] font-bold text-slate mb-1 uppercase tracking-[0.2em]">WhatsApp</span>
            <span className="text-white font-medium text-sm">Business Chat</span>
          </a>
        </motion.div>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 1 }}
          className="btn-primary flex items-center gap-3 group px-10"
        >
          Agenda una consulta gratuita
          <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform duration-300" />
        </motion.button>
      </main>

      <footer className="absolute bottom-10 text-slate text-[10px] tracking-[0.4em] uppercase opacity-30">
        © 2026 Structura. Tu tiempo, donde realmente importa.
      </footer>
    </div>
  );
}
